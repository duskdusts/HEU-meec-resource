
#非周期性方波的频谱图 A=1 omega_0=1
import numpy as np
import matplotlib.pyplot as plt
A = 1
x = np.arange(-20,20)+0.001  
x1 = np.arange(-20,20,0.001) 
y = 2*A*np.sin(x*np.pi/2)/(x*np.pi)
y1 = 2*A*np.sin(x1*np.pi/2)/(x1*np.pi)
fig = plt.figure()  
ax1 = fig.add_subplot(111)  
ax1.set_title('Cn-w')  
plt.xlabel('w')  
plt.ylabel('Cn')  
ax1.plot(x1,y1,'b--')
plt.vlines(x, 0 , y , 'k' , lw=3 , alpha=0.5)
plt.show() 
#周期性方波的频谱图
import numpy as np
import matplotlib.pyplot as plt
T=1
f = np.arange(-10,10,0.001)
y1 = T*np.sinc(np.pi*f*T)
plt.plot(f,y1)
plt.show() 